@extends('layouts.app')

@section('content')
    <input type="hidden" id="headerdata" value="{{ __('POST') }}">
    <div class="content-area">

        <div class="product-area">
            <div class="row">
                <div class="col-lg-12">
                    <div class="mr-table allproduct">

                        @include('admin.form-success')
                        <div class="table-contents">
                            <a class="btn btn-info" href="{{route('admin-blog-create')}}">
                          <i class="fa fa-plus"></i> {{ __('Add New Post') }}
                          </a>
                          </div>
                        <div class="table-responsiv">

                            <table id="geniustable" class="table table-hover dt-responsive" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>{{ __('SL NO') }}</th>
                                        <th>{{ __('Category') }}</th>
                                        <th width="40%">{{ __('Post Title') }}</th>
                                        <th>{{ __('Description') }}</th>
                                        <th>{{ __('Product Category') }}</th>
                                        <th>{{ __('Images') }}</th>
                                        <th>{{ __('Action') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($data as $value)
<tr>
    <td>{{$value->id}}</td>
    <td>{{$value->category->name}}</td>
    <td>{{$value->title}}</td>
    <td>{!!substr($value->details,0,500). '...'!!}</td>
    <td>{{$value->pcategory->name}}</td>
    <td><img class="img-md" src="{{ asset($value->photo)}}" alt="Image"></td>
    <td><a href="{{route('admin-blog-edit', encrypt($value->id))}}"><i class="fa fa-pencil-square-o" style="font-size:26px; color:blue;"></i></a> <a onclick="confirm_modal('{{route('admin-blog-delete', encrypt($value->id))}}');"><i class="fa fa-trash-o" style="font-size:26px; color:red;"></i></a></td>
</tr>
                                    @endforeach
                                </tbody>
                            </table>
                            <div class="text-center">
                                {{ $data->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    {{-- ADD / EDIT MODAL --}}

    <div class="modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">


        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="submit-loader">
                    <img src="{{asset('images/loader.gif')}}" alt="">
                </div>
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('Close') }}</button>
                </div>
            </div>
        </div>
    </div>

    {{-- ADD / EDIT MODAL ENDS --}}




    {{-- DELETE MODAL ENDS --}}
@endsection

