@extends('layouts.app')

@section('content')

<div class="col-lg-12">
    <div class="panel">
        <div class="panel-heading">
            <h3 class="panel-title">{{__('Category Information')}}</h3>
        </div>

        <!--Horizontal Form-->
        <!--===================================================-->
        <form class="form-horizontal" action="{{ route('categories.update', $category->id) }}" method="POST" enctype="multipart/form-data">
            <input name="_method" type="hidden" value="PATCH">
        	@csrf
            <div class="panel-body">
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="name">{{__('Name')}}</label>
                    <div class="col-sm-10">
                        <input type="text" placeholder="{{__('Name')}}" id="name" name="name" class="form-control" required value="{{$category->name}}">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="banner">{{__('Banner')}} <small>(200x300)</small></label>
                    <div class="col-sm-6">
                        <input type="file" id="banner" name="banner" class="form-control">

                    </div>
                    <div class="col-sm-4"> <img class="img-md" src="{{ asset($category->banner) }}" alt="{{__('banner')}}"></div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label" for="icon">{{__('Icon')}} <small>(32x32)</small></label>
                    <div class="col-sm-6">
                        <input type="file" id="icon" name="icon" class="form-control">
                    </div>
                    <div class="col-sm-4"> <img class="img-md" src="{{ asset($category->icon) }}" alt="{{__('icon')}}"></div>
                </div>
                <div class="form-group">
                    <label class="col-lg-2 control-label">{{__('Description')}}(Optional)</label>
                    <div class="col-lg-10">
                        <textarea class="editor" name="description">{{$category->description}}</textarea>
                    </div>
                </div>
            </div>
            <div class="panel-footer text-right">
                <button class="btn btn-purple" type="submit">{{__('Save')}}</button>
            </div>
        </form>
        <!--===================================================-->
        <!--End Horizontal Form-->

    </div>
</div>

@endsection
