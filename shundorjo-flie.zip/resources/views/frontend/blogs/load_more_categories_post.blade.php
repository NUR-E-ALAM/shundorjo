<div class="row">
    @foreach ($data['blogs'] as $value)
        <div class="blog-box row">
            <div class="col-md-4">
                <div class="post-media">
                    <a href="{{ route('health-and-bueaty-tips', $value->slug) }}" title="{{ $value->title }}">
                        <img src="{{ asset($value->photo) }}" alt="{{ $value->slug }}" class="img-fluid">
                        <div class="hovereffect"></div>
                    </a>
                </div><!-- end media -->
            </div><!-- end col -->

            <div class="blog-meta big-meta col-md-8">
                <span class="bg-aqua"><a href="{{ route('health-and-bueaty-tips', $value->slug) }}"
                        title="{{ $value->title }}">{{ $value->category->name }}</a></span>
                <h4><a href="{{ route('health-and-bueaty-tips', $value->slug) }}"
                        title="{{ $value->title }}">{{ $value->title }}</a></h4>
                <a href="{{ route('health-and-bueaty-tips', $value->slug) }}">
                    <p class="blog-txt-size">{!! substr($value->details, 0, 300) !!}.... </p>
                </a>
                <small><a href="{{ route('health-and-bueaty-tips', $value->slug) }}" title="{{$value->slug}}"><i class="fa fa-eye">{{$value->views}}</i>
                        </a></small>
                <small>{{date("F j, Y, g:i a", strtotime($value->created_at))}}</small>
                <small>Written by <a href="{{ route('health-and-bueaty-tips', $value->slug) }}" title="{{$value->create_by}}">{{$value->create_by}}</a></small>
            </div><!-- end meta -->
        </div><!-- end blog-box -->

        <hr class="invis">
    @endforeach

</div>
<!-- Pagination (hidden on the first load but used by AJAX) -->
@if ($data['blogs']->hasMorePages())
    <div class="pagination-links" style="display: none;">
        {{ $data['blogs']->appends(request()->query())->links() }}
    </div>
@endif


