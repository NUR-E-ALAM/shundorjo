@extends('frontend.layouts.app')

@section('title')
    Shundorjo Category List
@stop
@push('css')

    <link href=" {{ asset('frontend/blog/lib/slick/slick.css') }}" rel="stylesheet">
    <link href=" {{ asset('frontend/blog/lib/slick/slick-theme.css') }}" rel="stylesheet">
    <link href=" {{ asset('frontend/blog/css/style.css') }}" rel="stylesheet">

    <style>
        .blog-meta h3 {
            font-size: 14px;
            color: #797979;
        }

        a {
            text-decoration: none !important;
        }
    </style>


    @section('content')
        <section class="gry-bg">
            <!-- Breadcrumb Start -->
            <div class="breadcrumb-wrap">
                <div class="container">

                    <ul class="breadcrumb">
                        <li class="facl facl-angle-right"><a href="{{ route('shundorjo-care-tips') }}">Shundorjo Care Tips</a>
                        </li>
                        <li class="facl facl-angle-right"><a href="#">Categoy</a></li>
                        <li class="breadcrumb-item active">{{ $data['blogCategory']->name }}</li>
                    </ul>
                </div>
            </div>
            <!-- Breadcrumb End -->
            <section class="section wb">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
                            <div class="page-wrapper">
                                <div class="blog-list clearfix">
                                            <div id="blog-list">
                                                @include('frontend.blogs.load_more_categories_post')
                                                <!-- Include the product list here -->
                                            </div>

                                            <!-- Load More Button -->
                                            <div class="text-center my-4">
                                                <button id="load-more-blog" class="btn" style="background-color: #ec21cd;
                    ">Load More</button>
                                            </div>

                                    <div class="blog-box row">
                                        <div class="col-md-4">
                                            <div class="post-media">
                                                <a href="garden-single.html" title="">
                                                    <img src="upload/garden_sq_08.jpg" alt="" class="img-fluid">
                                                    <div class="hovereffect"></div>
                                                </a>
                                            </div><!-- end media -->
                                        </div><!-- end col -->


                                    </div><!-- end blog-box -->
                                </div><!-- end blog-list -->
                            </div><!-- end page-wrapper -->


                        </div><!-- end col -->

                        <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                            <div class="sidebar">
                                <div class="widget">
                                        <h4 class="sw-title text-pink text-lg">Shundorjo Care Category</h4>
                                        <div class="news-list">
                                            @foreach ($data['blogCategories'] as $value)
                                                <div class="nl-item">
                                                    <div class="nl-img">
                                                        <a href="">
                                                            <img src="{{ asset($value->banner) }}" width="100px" height="44px" />
                                                        </a>
                                                    </div>
                                                    <div class="nl-title">
                                                        <a href="">{{ @$value->name }}</a>
                                                    </div>
                                                </div>
                                            @endforeach


                                        </div>
                                </div><!-- end widget -->
                                <div class="widget">
                                        <div class="tab-news">
                                            <ul class="nav nav-pills nav-justified">
                                                <li class="nav-item">
                                                    <a class="nav-link active" data-toggle="pill" href="#latest">Latest</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-toggle="pill" href="#featured">Featured</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-toggle="pill" href="#popular">Popular</a>
                                                </li>

                                            </ul>

                                            <div class="tab-content">
                                                <div id="featured" class="container tab-pane fade">
                                                    @foreach (filter_products(\App\Models\Product::where('featured', 1))->limit(10)->get() as $key => $top_product)
                                                        <div class="mb-3 product-box-3 myDIV">
                                                            <div class="clearfix">
                                                                <div class="product-image float-left">
                                                                    <a href="{{ route('product', $top_product->slug) }}"><img
                                                                            src="{{ asset($top_product->thumbnail_img) }}"
                                                                            height="90" width="90" alt=""></a>
                                                                </div>
                                                                <div class="product-details float-left">
                                                                    <h4 class="title text-truncate-2">
                                                                        <a href="{{ route('product', $top_product->slug) }}"
                                                                            class="d-block">{{ $top_product->name }}</a>
                                                                    </h4>
                                                                    <div class="price-box">
                                                                        @if (home_base_price($top_product->id) != home_discounted_base_price($top_product->id))
                                                                            <del
                                                                                class="old-product-price strong-400">{{ home_base_price($top_product->id) }}</del>
                                                                        @endif
                                                                        <span
                                                                            class="product-price strong-600">{{ home_discounted_base_price($top_product->id) }}</span>
                                                                    </div>
                                                                    <button class="addCartBtn mt-3"
                                                                        onclick="showAddToCartModal({{ $top_product->id }})">
                                                                        <i class="fa fa-eye"></i>
                                                                        <article class="d-inline">Quick View</article>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>
                                                <div id="popular" class="container tab-pane fade">
                                                    @foreach (filter_products(\App\Models\Product::orderBy('num_of_sale', 'desc'))->limit(10)->get() as $key => $top_product)
                                                        <div class="mb-3 product-box-3 myDIV">
                                                            <div class="clearfix">
                                                                <div class="product-image float-left">
                                                                    <a href="{{ route('product', $top_product->slug) }}"><img
                                                                            src="{{ asset($top_product->thumbnail_img) }}"
                                                                            height="90" width="90" alt=""></a>
                                                                </div>
                                                                <div class="product-details float-left">
                                                                    <h4 class="title text-truncate-2">
                                                                        <a href="{{ route('product', $top_product->slug) }}"
                                                                            class="d-block">{{ $top_product->name }}</a>
                                                                    </h4>
                                                                    <div class="price-box">
                                                                        @if (home_base_price($top_product->id) != home_discounted_base_price($top_product->id))
                                                                            <del
                                                                                class="old-product-price strong-400">{{ home_base_price($top_product->id) }}</del>
                                                                        @endif
                                                                        <span
                                                                            class="product-price strong-600">{{ home_discounted_base_price($top_product->id) }}</span>
                                                                    </div>
                                                                    <button class="addCartBtn mt-3"
                                                                        onclick="showAddToCartModal({{ $top_product->id }})">
                                                                        <i class="fa fa-eye"></i>
                                                                        <article class="d-inline">Quick View</article>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>
                                                <div id="latest" class="container tab-pane active">
                                                    @foreach (filter_products(\App\Models\Product::where('category_id', $data['blogCategory']->pcategory_id))->orderBy('id', 'desc')->limit(10)->get() as $key => $top_product)
                                                        <div class="mb-3 product-box-3 myDIV">
                                                            <div class="clearfix">
                                                                <div class="product-image float-left">
                                                                    <a href="{{ route('product', $top_product->slug) }}"><img
                                                                            src="{{ asset($top_product->thumbnail_img) }}"
                                                                            height="90" width="90" alt=""></a>
                                                                </div>
                                                                <div class="product-details float-left">
                                                                    <h4 class="title text-truncate-2">
                                                                        <a href="{{ route('product', $top_product->slug) }}"
                                                                            class="d-block">{{ $top_product->name }}</a>
                                                                    </h4>
                                                                    <div class="price-box">
                                                                        @if (home_base_price($top_product->id) != home_discounted_base_price($top_product->id))
                                                                            <del
                                                                                class="old-product-price strong-400">{{ home_base_price($top_product->id) }}</del>
                                                                        @endif
                                                                        <span
                                                                            class="product-price strong-600">{{ home_discounted_base_price($top_product->id) }}</span>
                                                                    </div>
                                                                    <button class="addCartBtn mt-3"
                                                                        onclick="showAddToCartModal({{ $top_product->id }})">
                                                                        <i class="fa fa-eye"></i>
                                                                        <article class="d-inline">Quick View</article>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </div>
                                        </div>
                                </div>



                                <div class="widget">
                                    <h2 class="widget-title">Advertising</h2>
                                    <div class="banner-spot clearfix">
                                        <div class="banner-img">
                                                <a href="https://www.shundorjo.com"><img
                                                        src="{{ asset('frontend/blog') }}/img/ads-2.jpg" alt="Shundorjo is Authentic Cosmetics Products Hub" class="img-fluid"></a>
                                        </div><!-- end banner-img -->
                                    </div><!-- end banner -->
                                </div><!-- end widget -->

                                
                            </div><!-- end sidebar -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                </div><!-- end container -->
            </section>
            <!-- Main News End-->
        </section>

    @endsection
    @push('script')
        <script src="{{ asset('frontend/blog/lib/slick/slick.min.js') }}"></script>
        <script src="{{ asset('frontend/blog/lib/easing/easing.min.js') }}"></script>
        <script src="{{ asset('frontend/blog/js/main.js') }}"></script>
    @endpush
