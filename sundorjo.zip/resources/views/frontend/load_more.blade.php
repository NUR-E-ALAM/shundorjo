<div class="row productView">
    @foreach ($products as $key => $product)
        <div class="col-md-3 col-xl-3 col-lg-3 col-sm-6" style="padding: 5px !important">
            <div class="productDesign bg-white product-cat-box">
                <div class="productContainer">
                    <div class="productBadge">
                        @if ($product->todays_deal == 1)
                            <div class="proBadgePer">
                                New
                            </div>
                        @else
                        @endif
                        @if (percentage($product->id) > 0)
                            <div class="proBadge">
                                -{{ percentage($product->id) }}%
                            </div>
                        @endif
                    </div>
                    <a
                        href="{{ route('product', strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $product->slug)))) }}">
                        @if($product->thumbnail_webp && file_exists(public_path($product->thumbnail_webp)))
    <img class="img-fluid lazyload"
         data-src="{{ asset($product->thumbnail_webp) }}"
         alt="{{ $product->name }}">
@else
    <img class="img-fluid lazyload"
         data-src="{{ asset($product->thumbnail_img) }}"
         alt="{{ $product->name }}">
@endif
                    </a>

                    <div class="inner">
                        <button class="btn-invisible"
                            onclick="showAddToCartModal({{ $product->id }})">
                            <span class="iconify" data-icon="clarity:eye-show-solid"></span>
                            <article class="d-inline">Quick View</article>
                        </button>
                        @if($product->is_stock==1)
                            <button class="btn-invisible" onclick="buyNow({{$product->id}})">
                                <span class="iconify" data-icon="ei:cart"></span>
                                <article class="d-inline">Order Now</article>
                            </button>
                            @else
                                <button class="btn-invisible">
                                    <span class="iconify" data-icon="ei:cart"></span>
                                    <article class="d-inline">Stock Out</article>
                                </button>
                            @endif



                    </div>
                    <div class="product-info">

                        <div class="price-box text-center">
                            <span
                            class="product-price strong-600">{{ home_discounted_base_price($product->id) }}</span>
                            @if (home_base_price($product->id) != home_discounted_base_price($product->id))

                                <del
                                    class="old-product-price strong-400">{{ home_base_price($product->id) }}</del>

                            @endif

                        </div>
                        <h6 class="product-title">

                            <a class=""
                                href="{{ route('product', strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $product->slug)))) }}">{{ \Illuminate\Support\Str::limit($product->name, 40) }}
                            </a>
                        </h6>



                    </div>
                </div>


            </div>
        </div>
    @endforeach
    <!-- Pagination (hidden on the first load but used by AJAX) -->
@if ($products->hasMorePages())
<div class="pagination-links" style="display: none;">
    {{ $products->appends(request()->query())->links() }}
</div>
@endif
</div>

