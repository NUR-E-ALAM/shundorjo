<?php
/**
 * @see https://github.com/artesaos/seotools
 */

return [
    'meta' => [
        /*
         * The default configurations to be used by the meta generator.
         */
        'defaults'       => [
            'title'        => "Shundorjo Care | Medicated Care Shop In Bangladesh", // set false to total remove
            'titleBefore'  => false, // Put defaults.title before page title, like 'It's Over 9000! - Dashboard'
            'description'  => 'Your one-stop destination for beauty, wellness, and style in Bangladesh. We offer a curated selection of premium cosmetics, essential medicines, personal care products, and stylish clothing. Experience the joy of shopping with US.', // set false to total remove
            'separator'    => ' - ',
            'keywords'     => ['cosmetics, skin care, health and beauty, organic products, medicated products, natural skincare, herbal beauty products, beauty products in Bangladesh, skin treatment, anti-acne products, organic face cream, authentic cosmetics, hair care, natural oils, body lotion, sensitive skin products, natural beauty, herbal remedies, acne care, dry skin solution, moisturizers, Bangladesh beauty shop, online cosmetics store, authentic organic products, hair repair products, makeup essentials, beauty care Bangladesh'],
            'canonical'    => false, // Set to null or 'full' to use Url::full(), set to 'current' to use Url::current(), set false to total remove
            'robots'       => false, // Set to 'all', 'none' or any combination of index/noindex and follow/nofollow
        ],
        /*
         * Webmaster tags are always added.
         */
        'webmaster_tags' => [
            'google'    => null,
            'bing'      => null,
            'alexa'     => null,
            'pinterest' => null,
            'yandex'    => null,
            'norton'    => null,
        ],

        'add_notranslate_class' => false,
    ],
    'opengraph' => [
        /*
         * The default configurations to be used by the opengraph generator.
         */
        'defaults' => [
            'title'       => 'Shundorjo Care | Medicated Care Shop In Bangladesh', // set false to total remove
            'description' => 'Your one-stop destination for beauty, wellness, and style in Bangladesh. We offer a curated selection of premium cosmetics, essential medicines, personal care products, and stylish clothing. Experience the joy of shopping with US.', // set false to total remove
            'url'         => false, // Set null for using Url::current(), set false to total remove
            'type'        => false,
            'site_name'   => false,
            'images'      => [],
        ],
    ],
    'twitter' => [
        /*
         * The default values to be used by the twitter cards generator.
         */
        'defaults' => [
            //'card'        => 'summary',
            //'site'        => '@LuizVinicius73',
        ],
    ],
    'json-ld' => [
        /*
         * The default configurations to be used by the json-ld generator.
         */
        'defaults' => [
            'title'       => 'Shundorjo Care | Medicated Care Shop In Bangladesh', // set false to total remove
            'description' => 'Your one-stop destination for beauty, wellness, and style in Bangladesh. We offer a curated selection of premium cosmetics, essential medicines, personal care products, and stylish clothing. Experience the joy of shopping with US.', // set false to total remove
            'url'         => false, // Set to null or 'full' to use Url::full(), set to 'current' to use Url::current(), set false to total remove
            'type'        => 'Website',
            'images'      => [],
        ],
    ],
];
